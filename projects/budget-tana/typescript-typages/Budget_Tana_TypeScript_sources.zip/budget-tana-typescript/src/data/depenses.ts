// Jeu de données pédagogique : dix dépenses fictives à Antananarivo.
// La structure est une liste d'objets ordinaires, sans serveur ni stockage.
import type { Expense } from '../types.ts';

export const depenses: Expense[] = [
  {
    id: 'sep-logement',
    date: '2026-09-02',
    categorie: 'Logement',
    libelle: 'Loyer septembre',
    montant: 180000
  },
  {
    id: 'sep-repas',
    date: '2026-09-06',
    categorie: 'Repas',
    libelle: 'Repas septembre',
    montant: 120000
  },
  {
    id: 'sep-transport',
    date: '2026-09-08',
    categorie: 'Transport',
    libelle: 'Transport septembre',
    montant: 40000
  },
  {
    id: 'sep-internet',
    date: '2026-09-12',
    categorie: 'Internet',
    libelle: 'Connexion septembre',
    montant: 25000
  },
  {
    id: 'sep-fournitures',
    date: '2026-09-15',
    categorie: 'Fournitures',
    libelle: 'Cahiers septembre',
    montant: 10000
  },
  {
    id: 'oct-logement',
    date: '2026-10-02',
    categorie: 'Logement',
    libelle: 'Loyer octobre',
    montant: 180000
  },
  {
    id: 'oct-repas',
    date: '2026-10-06',
    categorie: 'Repas',
    libelle: 'Repas octobre',
    montant: 135000,
    note: 'Dépense fictive'
  },
  {
    id: 'oct-transport',
    date: '2026-10-08',
    categorie: 'Transport',
    libelle: 'Transport octobre',
    montant: 45000
  },
  {
    id: 'oct-internet',
    date: '2026-10-12',
    categorie: 'Internet',
    libelle: 'Connexion octobre',
    montant: 25000
  },
  {
    id: 'oct-fournitures',
    date: '2026-10-15',
    categorie: 'Fournitures',
    libelle: 'Cahiers octobre',
    montant: 20000
  },
];
